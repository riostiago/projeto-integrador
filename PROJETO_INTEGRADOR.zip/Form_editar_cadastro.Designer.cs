﻿
namespace pagina_inicio
{
    partial class Form_editar_cadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_editar_cadastro));
            this.tacontrol_cadcliente = new System.Windows.Forms.TabControl();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.limite_cred = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.informacoes = new System.Windows.Forms.RichTextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.cep = new System.Windows.Forms.MaskedTextBox();
            this.data_nasc = new System.Windows.Forms.MaskedTextBox();
            this.cnpj = new System.Windows.Forms.MaskedTextBox();
            this.cpf = new System.Windows.Forms.MaskedTextBox();
            this.btn_exibir = new System.Windows.Forms.Button();
            this.btn_excluir = new System.Windows.Forms.Button();
            this.EMAIL = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.checkboxsexo_f = new System.Windows.Forms.CheckBox();
            this.checkboxsexo_m = new System.Windows.Forms.CheckBox();
            this.nasc = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.pessoa_juridica = new System.Windows.Forms.CheckBox();
            this.pessoa_fisica = new System.Windows.Forms.CheckBox();
            this.btn_voltar = new System.Windows.Forms.Button();
            this.btn_salvar = new System.Windows.Forms.Button();
            this.estado = new System.Windows.Forms.TextBox();
            this.estadoo = new System.Windows.Forms.Label();
            this.complemento = new System.Windows.Forms.TextBox();
            this.complementoo = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cidade = new System.Windows.Forms.TextBox();
            this.cidadee = new System.Windows.Forms.Label();
            this.bairro = new System.Windows.Forms.TextBox();
            this.bairroo = new System.Windows.Forms.Label();
            this.num = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cepp = new System.Windows.Forms.Label();
            this.rua = new System.Windows.Forms.TextBox();
            this.nome_rua = new System.Windows.Forms.Label();
            this.sobrenome = new System.Windows.Forms.TextBox();
            this.nome = new System.Windows.Forms.TextBox();
            this.cod_cliente = new System.Windows.Forms.TextBox();
            this.sobre = new System.Windows.Forms.Label();
            this.cliente = new System.Windows.Forms.Label();
            this.nome_cliente = new System.Windows.Forms.Label();
            this.tacontrol_cadcliente.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tacontrol_cadcliente
            // 
            this.tacontrol_cadcliente.Controls.Add(this.tabPage3);
            this.tacontrol_cadcliente.Controls.Add(this.tabPage4);
            this.tacontrol_cadcliente.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tacontrol_cadcliente.Location = new System.Drawing.Point(0, 0);
            this.tacontrol_cadcliente.Name = "tacontrol_cadcliente";
            this.tacontrol_cadcliente.SelectedIndex = 0;
            this.tacontrol_cadcliente.Size = new System.Drawing.Size(572, 522);
            this.tacontrol_cadcliente.TabIndex = 1;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.tabPage4.Controls.Add(this.button5);
            this.tabPage4.Controls.Add(this.button6);
            this.tabPage4.Controls.Add(this.button7);
            this.tabPage4.Controls.Add(this.label16);
            this.tabPage4.Controls.Add(this.limite_cred);
            this.tabPage4.Controls.Add(this.label15);
            this.tabPage4.Controls.Add(this.informacoes);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(564, 496);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "Mais opções";
            // 
            // button5
            // 
            this.button5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button5.Location = new System.Drawing.Point(220, 440);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(87, 23);
            this.button5.TabIndex = 54;
            this.button5.Text = "&VOLTAR";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button6.Location = new System.Drawing.Point(326, 440);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(87, 23);
            this.button6.TabIndex = 53;
            this.button6.Text = "&LIMPAR";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button7.Location = new System.Drawing.Point(437, 440);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(87, 23);
            this.button7.TabIndex = 52;
            this.button7.Text = "&SALVAR";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(46, 81);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(139, 15);
            this.label16.TabIndex = 3;
            this.label16.Text = "LIMITE DE CREDITO";
            // 
            // limite_cred
            // 
            this.limite_cred.Location = new System.Drawing.Point(49, 99);
            this.limite_cred.Name = "limite_cred";
            this.limite_cred.Size = new System.Drawing.Size(215, 20);
            this.limite_cred.TabIndex = 2;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(46, 132);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(205, 15);
            this.label15.TabIndex = 1;
            this.label15.Text = "INFORMAÇÕES / RESTRIÇÕES";
            // 
            // informacoes
            // 
            this.informacoes.Location = new System.Drawing.Point(49, 150);
            this.informacoes.Name = "informacoes";
            this.informacoes.Size = new System.Drawing.Size(455, 169);
            this.informacoes.TabIndex = 0;
            this.informacoes.Text = "";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.SystemColors.ControlDark;
            this.tabPage3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPage3.Controls.Add(this.cep);
            this.tabPage3.Controls.Add(this.data_nasc);
            this.tabPage3.Controls.Add(this.cnpj);
            this.tabPage3.Controls.Add(this.cpf);
            this.tabPage3.Controls.Add(this.btn_exibir);
            this.tabPage3.Controls.Add(this.btn_excluir);
            this.tabPage3.Controls.Add(this.EMAIL);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Controls.Add(this.checkboxsexo_f);
            this.tabPage3.Controls.Add(this.checkboxsexo_m);
            this.tabPage3.Controls.Add(this.nasc);
            this.tabPage3.Controls.Add(this.label14);
            this.tabPage3.Controls.Add(this.pessoa_juridica);
            this.tabPage3.Controls.Add(this.pessoa_fisica);
            this.tabPage3.Controls.Add(this.btn_voltar);
            this.tabPage3.Controls.Add(this.btn_salvar);
            this.tabPage3.Controls.Add(this.estado);
            this.tabPage3.Controls.Add(this.estadoo);
            this.tabPage3.Controls.Add(this.complemento);
            this.tabPage3.Controls.Add(this.complementoo);
            this.tabPage3.Controls.Add(this.label1);
            this.tabPage3.Controls.Add(this.cidade);
            this.tabPage3.Controls.Add(this.cidadee);
            this.tabPage3.Controls.Add(this.bairro);
            this.tabPage3.Controls.Add(this.bairroo);
            this.tabPage3.Controls.Add(this.num);
            this.tabPage3.Controls.Add(this.label2);
            this.tabPage3.Controls.Add(this.cepp);
            this.tabPage3.Controls.Add(this.rua);
            this.tabPage3.Controls.Add(this.nome_rua);
            this.tabPage3.Controls.Add(this.sobrenome);
            this.tabPage3.Controls.Add(this.nome);
            this.tabPage3.Controls.Add(this.cod_cliente);
            this.tabPage3.Controls.Add(this.sobre);
            this.tabPage3.Controls.Add(this.cliente);
            this.tabPage3.Controls.Add(this.nome_cliente);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(564, 496);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "Informações do Cliente";
            // 
            // cep
            // 
            this.cep.Location = new System.Drawing.Point(60, 307);
            this.cep.Mask = "00000-000";
            this.cep.Name = "cep";
            this.cep.Size = new System.Drawing.Size(113, 20);
            this.cep.TabIndex = 67;
            this.cep.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // data_nasc
            // 
            this.data_nasc.Location = new System.Drawing.Point(315, 160);
            this.data_nasc.Mask = "00/00/0000";
            this.data_nasc.Name = "data_nasc";
            this.data_nasc.Size = new System.Drawing.Size(174, 20);
            this.data_nasc.TabIndex = 66;
            this.data_nasc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // cnpj
            // 
            this.cnpj.Location = new System.Drawing.Point(335, 67);
            this.cnpj.Mask = "00,000,000/0000-00";
            this.cnpj.Name = "cnpj";
            this.cnpj.Size = new System.Drawing.Size(154, 20);
            this.cnpj.TabIndex = 65;
            this.cnpj.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // cpf
            // 
            this.cpf.Location = new System.Drawing.Point(158, 67);
            this.cpf.Mask = "000,000,000-00";
            this.cpf.Name = "cpf";
            this.cpf.Size = new System.Drawing.Size(152, 20);
            this.cpf.TabIndex = 64;
            this.cpf.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btn_exibir
            // 
            this.btn_exibir.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_exibir.BackColor = System.Drawing.SystemColors.Highlight;
            this.btn_exibir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_exibir.Location = new System.Drawing.Point(348, 417);
            this.btn_exibir.Name = "btn_exibir";
            this.btn_exibir.Size = new System.Drawing.Size(137, 23);
            this.btn_exibir.TabIndex = 63;
            this.btn_exibir.Text = "&EXIBIR";
            this.btn_exibir.UseVisualStyleBackColor = false;
            this.btn_exibir.Click += new System.EventHandler(this.btn_exibir_Click);
            // 
            // btn_excluir
            // 
            this.btn_excluir.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_excluir.BackColor = System.Drawing.Color.Red;
            this.btn_excluir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_excluir.Location = new System.Drawing.Point(158, 450);
            this.btn_excluir.Name = "btn_excluir";
            this.btn_excluir.Size = new System.Drawing.Size(180, 23);
            this.btn_excluir.TabIndex = 62;
            this.btn_excluir.Text = "&EXCLUIR CADASTRO";
            this.btn_excluir.UseVisualStyleBackColor = false;
            this.btn_excluir.Click += new System.EventHandler(this.btn_excluir_Click);
            // 
            // EMAIL
            // 
            this.EMAIL.Location = new System.Drawing.Point(60, 205);
            this.EMAIL.Name = "EMAIL";
            this.EMAIL.Size = new System.Drawing.Size(429, 20);
            this.EMAIL.TabIndex = 61;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(60, 187);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(57, 15);
            this.label17.TabIndex = 60;
            this.label17.Text = "E-MAIL:";
            // 
            // checkboxsexo_f
            // 
            this.checkboxsexo_f.AutoSize = true;
            this.checkboxsexo_f.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkboxsexo_f.Location = new System.Drawing.Point(321, 112);
            this.checkboxsexo_f.Name = "checkboxsexo_f";
            this.checkboxsexo_f.Size = new System.Drawing.Size(33, 17);
            this.checkboxsexo_f.TabIndex = 59;
            this.checkboxsexo_f.Text = "F";
            this.checkboxsexo_f.UseVisualStyleBackColor = true;
            this.checkboxsexo_f.CheckedChanged += new System.EventHandler(this.checkboxsexo_f_CheckedChanged);
            // 
            // checkboxsexo_m
            // 
            this.checkboxsexo_m.AutoSize = true;
            this.checkboxsexo_m.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkboxsexo_m.Location = new System.Drawing.Point(277, 112);
            this.checkboxsexo_m.Name = "checkboxsexo_m";
            this.checkboxsexo_m.Size = new System.Drawing.Size(36, 17);
            this.checkboxsexo_m.TabIndex = 58;
            this.checkboxsexo_m.Text = "M";
            this.checkboxsexo_m.UseVisualStyleBackColor = true;
            this.checkboxsexo_m.CheckedChanged += new System.EventHandler(this.checkboxsexo_m_CheckedChanged);
            // 
            // nasc
            // 
            this.nasc.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.nasc.AutoSize = true;
            this.nasc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nasc.Location = new System.Drawing.Point(314, 144);
            this.nasc.Name = "nasc";
            this.nasc.Size = new System.Drawing.Size(150, 13);
            this.nasc.TabIndex = 56;
            this.nasc.Text = "DATA DE NASCIMENTO:";
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(328, 51);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(42, 13);
            this.label14.TabIndex = 54;
            this.label14.Text = "CNPJ:";
            // 
            // pessoa_juridica
            // 
            this.pessoa_juridica.AutoSize = true;
            this.pessoa_juridica.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pessoa_juridica.Location = new System.Drawing.Point(170, 15);
            this.pessoa_juridica.Name = "pessoa_juridica";
            this.pessoa_juridica.Size = new System.Drawing.Size(117, 17);
            this.pessoa_juridica.TabIndex = 53;
            this.pessoa_juridica.Text = "Pessoa Jurídica";
            this.pessoa_juridica.UseVisualStyleBackColor = true;
            this.pessoa_juridica.CheckedChanged += new System.EventHandler(this.pessoa_juridica_CheckedChanged);
            // 
            // pessoa_fisica
            // 
            this.pessoa_fisica.AutoSize = true;
            this.pessoa_fisica.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pessoa_fisica.Location = new System.Drawing.Point(60, 15);
            this.pessoa_fisica.Name = "pessoa_fisica";
            this.pessoa_fisica.Size = new System.Drawing.Size(106, 17);
            this.pessoa_fisica.TabIndex = 52;
            this.pessoa_fisica.Text = "Pessoa Física";
            this.pessoa_fisica.UseVisualStyleBackColor = true;
            this.pessoa_fisica.CheckedChanged += new System.EventHandler(this.pessoa_fisica_CheckedChanged);
            // 
            // btn_voltar
            // 
            this.btn_voltar.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_voltar.BackColor = System.Drawing.Color.DodgerBlue;
            this.btn_voltar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_voltar.Location = new System.Drawing.Point(61, 450);
            this.btn_voltar.Name = "btn_voltar";
            this.btn_voltar.Size = new System.Drawing.Size(87, 23);
            this.btn_voltar.TabIndex = 51;
            this.btn_voltar.Text = "&VOLTAR";
            this.btn_voltar.UseVisualStyleBackColor = false;
            this.btn_voltar.Click += new System.EventHandler(this.btn_voltar_Click);
            // 
            // btn_salvar
            // 
            this.btn_salvar.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_salvar.BackColor = System.Drawing.Color.Lime;
            this.btn_salvar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_salvar.Location = new System.Drawing.Point(348, 450);
            this.btn_salvar.Name = "btn_salvar";
            this.btn_salvar.Size = new System.Drawing.Size(137, 23);
            this.btn_salvar.TabIndex = 48;
            this.btn_salvar.Text = "&SALVAR EDIÇÃO";
            this.btn_salvar.UseVisualStyleBackColor = false;
            this.btn_salvar.Click += new System.EventHandler(this.btn_salvar_Click);
            // 
            // estado
            // 
            this.estado.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.estado.Location = new System.Drawing.Point(252, 363);
            this.estado.Name = "estado";
            this.estado.Size = new System.Drawing.Size(233, 20);
            this.estado.TabIndex = 47;
            // 
            // estadoo
            // 
            this.estadoo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.estadoo.AutoSize = true;
            this.estadoo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.estadoo.Location = new System.Drawing.Point(249, 347);
            this.estadoo.Name = "estadoo";
            this.estadoo.Size = new System.Drawing.Size(61, 13);
            this.estadoo.TabIndex = 46;
            this.estadoo.Text = "ESTADO:";
            // 
            // complemento
            // 
            this.complemento.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.complemento.Location = new System.Drawing.Point(179, 307);
            this.complemento.Name = "complemento";
            this.complemento.Size = new System.Drawing.Size(152, 20);
            this.complemento.TabIndex = 45;
            // 
            // complementoo
            // 
            this.complementoo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.complementoo.AutoSize = true;
            this.complementoo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.complementoo.Location = new System.Drawing.Point(176, 291);
            this.complementoo.Name = "complementoo";
            this.complementoo.Size = new System.Drawing.Size(105, 13);
            this.complementoo.TabIndex = 44;
            this.complementoo.Text = "COMPLEMENTO:";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(155, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 42;
            this.label1.Text = "CPF:";
            // 
            // cidade
            // 
            this.cidade.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cidade.Location = new System.Drawing.Point(60, 363);
            this.cidade.Name = "cidade";
            this.cidade.Size = new System.Drawing.Size(174, 20);
            this.cidade.TabIndex = 41;
            // 
            // cidadee
            // 
            this.cidadee.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cidadee.AutoSize = true;
            this.cidadee.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cidadee.Location = new System.Drawing.Point(57, 347);
            this.cidadee.Name = "cidadee";
            this.cidadee.Size = new System.Drawing.Size(57, 13);
            this.cidadee.TabIndex = 40;
            this.cidadee.Text = "CIDADE:";
            // 
            // bairro
            // 
            this.bairro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bairro.Location = new System.Drawing.Point(337, 307);
            this.bairro.Name = "bairro";
            this.bairro.Size = new System.Drawing.Size(148, 20);
            this.bairro.TabIndex = 38;
            // 
            // bairroo
            // 
            this.bairroo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bairroo.AutoSize = true;
            this.bairroo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bairroo.Location = new System.Drawing.Point(334, 291);
            this.bairroo.Name = "bairroo";
            this.bairroo.Size = new System.Drawing.Size(58, 13);
            this.bairroo.TabIndex = 37;
            this.bairroo.Text = "BAIRRO:";
            // 
            // num
            // 
            this.num.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.num.Location = new System.Drawing.Point(376, 257);
            this.num.Name = "num";
            this.num.Size = new System.Drawing.Size(109, 20);
            this.num.TabIndex = 36;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(376, 241);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(20, 13);
            this.label2.TabIndex = 35;
            this.label2.Text = "N:";
            // 
            // cepp
            // 
            this.cepp.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cepp.AutoSize = true;
            this.cepp.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cepp.Location = new System.Drawing.Point(57, 291);
            this.cepp.Name = "cepp";
            this.cepp.Size = new System.Drawing.Size(35, 13);
            this.cepp.TabIndex = 34;
            this.cepp.Text = "CEP:";
            // 
            // rua
            // 
            this.rua.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rua.Location = new System.Drawing.Point(60, 257);
            this.rua.Name = "rua";
            this.rua.Size = new System.Drawing.Size(310, 20);
            this.rua.TabIndex = 33;
            // 
            // nome_rua
            // 
            this.nome_rua.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.nome_rua.AutoSize = true;
            this.nome_rua.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nome_rua.Location = new System.Drawing.Point(57, 241);
            this.nome_rua.Name = "nome_rua";
            this.nome_rua.Size = new System.Drawing.Size(37, 13);
            this.nome_rua.TabIndex = 32;
            this.nome_rua.Text = "RUA:";
            // 
            // sobrenome
            // 
            this.sobrenome.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.sobrenome.Location = new System.Drawing.Point(60, 160);
            this.sobrenome.Name = "sobrenome";
            this.sobrenome.Size = new System.Drawing.Size(234, 20);
            this.sobrenome.TabIndex = 31;
            // 
            // nome
            // 
            this.nome.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.nome.Location = new System.Drawing.Point(60, 112);
            this.nome.Name = "nome";
            this.nome.Size = new System.Drawing.Size(195, 20);
            this.nome.TabIndex = 30;
            // 
            // cod_cliente
            // 
            this.cod_cliente.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cod_cliente.Location = new System.Drawing.Point(60, 67);
            this.cod_cliente.Name = "cod_cliente";
            this.cod_cliente.Size = new System.Drawing.Size(79, 20);
            this.cod_cliente.TabIndex = 29;
            // 
            // sobre
            // 
            this.sobre.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.sobre.AutoSize = true;
            this.sobre.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sobre.Location = new System.Drawing.Point(57, 144);
            this.sobre.Name = "sobre";
            this.sobre.Size = new System.Drawing.Size(89, 13);
            this.sobre.TabIndex = 28;
            this.sobre.Text = "SOBRENOME:";
            // 
            // cliente
            // 
            this.cliente.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cliente.AutoSize = true;
            this.cliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cliente.Location = new System.Drawing.Point(57, 51);
            this.cliente.Name = "cliente";
            this.cliente.Size = new System.Drawing.Size(37, 13);
            this.cliente.TabIndex = 27;
            this.cliente.Text = "COD:";
            // 
            // nome_cliente
            // 
            this.nome_cliente.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.nome_cliente.AutoSize = true;
            this.nome_cliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nome_cliente.Location = new System.Drawing.Point(57, 96);
            this.nome_cliente.Name = "nome_cliente";
            this.nome_cliente.Size = new System.Drawing.Size(47, 13);
            this.nome_cliente.TabIndex = 26;
            this.nome_cliente.Text = "NOME:";
            // 
            // Form_editar_cadastro
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.ClientSize = new System.Drawing.Size(572, 522);
            this.Controls.Add(this.tacontrol_cadcliente);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form_editar_cadastro";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Formulario Para Edição de Cadastro";
            this.Load += new System.EventHandler(this.Form_editar_cadastro_Load);
            this.tacontrol_cadcliente.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tacontrol_cadcliente;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TextBox EMAIL;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.CheckBox checkboxsexo_f;
        private System.Windows.Forms.CheckBox checkboxsexo_m;
        private System.Windows.Forms.Label nasc;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.CheckBox pessoa_juridica;
        private System.Windows.Forms.CheckBox pessoa_fisica;
        private System.Windows.Forms.Button btn_salvar;
        private System.Windows.Forms.TextBox estado;
        private System.Windows.Forms.Label estadoo;
        private System.Windows.Forms.TextBox complemento;
        private System.Windows.Forms.Label complementoo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox cidade;
        private System.Windows.Forms.Label cidadee;
        private System.Windows.Forms.TextBox bairro;
        private System.Windows.Forms.Label bairroo;
        private System.Windows.Forms.TextBox num;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label cepp;
        private System.Windows.Forms.TextBox rua;
        private System.Windows.Forms.Label nome_rua;
        private System.Windows.Forms.TextBox sobrenome;
        private System.Windows.Forms.TextBox nome;
        private System.Windows.Forms.Label sobre;
        private System.Windows.Forms.Label cliente;
        private System.Windows.Forms.Label nome_cliente;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox limite_cred;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.RichTextBox informacoes;
        private System.Windows.Forms.TextBox cod_cliente;
        private System.Windows.Forms.Button btn_excluir;
        private System.Windows.Forms.Button btn_exibir;
        private System.Windows.Forms.MaskedTextBox cpf;
        private System.Windows.Forms.MaskedTextBox cnpj;
        private System.Windows.Forms.MaskedTextBox data_nasc;
        private System.Windows.Forms.MaskedTextBox cep;
        public System.Windows.Forms.Button btn_voltar;
    }
}